/*
Navicat MySQL Data Transfer

Source Server         : Harlan Instruments
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : mysql

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2019-12-09 22:11:29
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `customer`
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `Customer_ID` varchar(10) NOT NULL,
  `Customer_Name` varchar(80) DEFAULT NULL,
  `Customer_Gender` varchar(8) DEFAULT NULL,
  `Customer_Address` varchar(150) DEFAULT NULL,
  `Customer_Contact` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`Customer_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES ('A0001', 'John Herring', 'Male', 'Dhaka_Bangladesh', '+0182147447');
INSERT INTO `customer` VALUES ('A0002', 'Cary Robinson ', 'Male', 'Dhaka_Bangladesh', '+0182147447');
INSERT INTO `customer` VALUES ('A0003', 'Willy Wonka', 'Female', 'Dhaka_Bangladesh', '+0182147447');

-- ----------------------------
-- Table structure for `instrument`
-- ----------------------------
DROP TABLE IF EXISTS `instrument`;
CREATE TABLE `instrument` (
  `Instrument_Code` varchar(8) NOT NULL,
  `Instrument_Name` varchar(40) DEFAULT NULL,
  `Instrument_Description` varchar(200) DEFAULT NULL,
  `Instrument_Price` int(7) DEFAULT NULL,
  `Instrument_Quality` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`Instrument_Code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of instrument
-- ----------------------------
INSERT INTO `instrument` VALUES ('B0001', ' Guitar ', 'Instrument_Description', '15000', 'Good');
INSERT INTO `instrument` VALUES ('B0002', 'Cello  ', 'Instrument_Description', '5000', 'Batter');
INSERT INTO `instrument` VALUES ('B0003', ' Trumpet  ', 'Instrument_Description', '20000', 'Best');
INSERT INTO `instrument` VALUES ('B0004', ' Violin ', 'Instrument_Description', '15000', 'Good');
INSERT INTO `instrument` VALUES ('B001', ' Guitar ', 'Instrument_Description', '15000', 'Good');
INSERT INTO `instrument` VALUES ('B002', 'Cello  ', 'Instrument_Description', '5000', 'Batter');
INSERT INTO `instrument` VALUES ('B003', ' Trumpet  ', 'Instrument_Description', '20000', 'Best');
INSERT INTO `instrument` VALUES ('B004', ' Violin ', 'Instrument_Description', '15000', 'Good');

-- ----------------------------
-- Table structure for `order_instrument`
-- ----------------------------
DROP TABLE IF EXISTS `order_instrument`;
CREATE TABLE `order_instrument` (
  `Order_Instrument_ID` varchar(10) NOT NULL,
  `Instrument_Code` varchar(8) DEFAULT NULL,
  `Order_ID` int(5) DEFAULT NULL,
  `Quantity_Ordered` int(4) DEFAULT NULL,
  PRIMARY KEY (`Order_Instrument_ID`),
  KEY `Instrument_Code` (`Instrument_Code`),
  KEY `Order_ID` (`Order_ID`),
  CONSTRAINT `order_instrument_ibfk_1` FOREIGN KEY (`Instrument_Code`) REFERENCES `instrument` (`Instrument_Code`),
  CONSTRAINT `order_instrument_ibfk_2` FOREIGN KEY (`Order_ID`) REFERENCES `orders` (`Order_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of order_instrument
-- ----------------------------
INSERT INTO `order_instrument` VALUES ('C0001', 'B0001', '33', '2');
INSERT INTO `order_instrument` VALUES ('C0002', 'B0001', '34', '1');
INSERT INTO `order_instrument` VALUES ('C0003', 'B0002', '76', '3');
INSERT INTO `order_instrument` VALUES ('C0004', 'B0003', '11', '2');

-- ----------------------------
-- Table structure for `orders`
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `Order_ID` int(5) NOT NULL,
  `Order_Date` date DEFAULT NULL,
  `Order_Total` varchar(100) DEFAULT NULL,
  `Payment_Type` varchar(10) DEFAULT NULL,
  `Customer_ID` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`Order_ID`),
  KEY `Customer_ID` (`Customer_ID`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`Customer_ID`) REFERENCES `customer` (`Customer_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('11', '2007-12-12', '1', 'postpaid', 'A0001');
INSERT INTO `orders` VALUES ('33', '2007-12-12', '4', 'card', 'A0002');
INSERT INTO `orders` VALUES ('34', '2007-12-12', '4', 'card', 'A0002');
INSERT INTO `orders` VALUES ('76', '2007-12-12', '1', 'postpaid', 'A0003');

-- ----------------------------
-- Table structure for `service`
-- ----------------------------
DROP TABLE IF EXISTS `service`;
CREATE TABLE `service` (
  `Service_ID` int(5) NOT NULL,
  `Service_Name` varchar(50) DEFAULT NULL,
  `Service_Date` date DEFAULT NULL,
  `Service_Schedule` varchar(10) DEFAULT NULL,
  `Order_ID` int(5) DEFAULT NULL,
  `Staff_ID` int(10) DEFAULT NULL,
  PRIMARY KEY (`Service_ID`),
  KEY `Order_ID` (`Order_ID`),
  KEY `Staff_ID` (`Staff_ID`),
  CONSTRAINT `service_ibfk_1` FOREIGN KEY (`Order_ID`) REFERENCES `orders` (`Order_ID`),
  CONSTRAINT `service_ibfk_2` FOREIGN KEY (`Staff_ID`) REFERENCES `staff` (`Staff_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of service
-- ----------------------------
INSERT INTO `service` VALUES ('3121', 'Delivery', '2007-12-11', '1 week ', '11', '111');
INSERT INTO `service` VALUES ('3434', 'Repair', '2007-12-11', '2 weeks ', '33', '111');
INSERT INTO `service` VALUES ('3439', 'Repair', '2007-12-15', '1 week', '33', '222');
INSERT INTO `service` VALUES ('3878', 'Delivery', '2007-12-11', '2 days ', '76', '333');
INSERT INTO `service` VALUES ('4343', 'Delivery', '2007-12-11', '5 days ', '33', '111');
INSERT INTO `service` VALUES ('6766', 'Repair', '2007-12-11', '10 days ', '11', '111');

-- ----------------------------
-- Table structure for `staff`
-- ----------------------------
DROP TABLE IF EXISTS `staff`;
CREATE TABLE `staff` (
  `Staff_ID` int(10) NOT NULL,
  `Staff_Name` varchar(60) DEFAULT NULL,
  `Staff_Address` varchar(100) DEFAULT NULL,
  `Staff_Work_Time` varchar(5) DEFAULT NULL,
  `Staff_Contact` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`Staff_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of staff
-- ----------------------------
INSERT INTO `staff` VALUES ('111', 'Ben Roberts', 'dhaka', '6 hou', '017339873');
INSERT INTO `staff` VALUES ('222', 'Gary Crowle', 'comilla', '7 hou', '018339873');
INSERT INTO `staff` VALUES ('333', 'Anita Magneson', 'dhaka', '6.5 h', '017339873');
